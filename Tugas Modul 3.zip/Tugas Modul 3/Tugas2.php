<?php
    for($no=1;$no<=25;$no++)
        {
            if($no % 2 == 0)
                {echo "$no = Bilangan Genap<br>";}
            else
                {echo "$no = Bilangan Ganjil<br>";}
        }
?>